1. Comments need to be provided for service methods and factory methods
2. Entire application constants need to be managed in centralized place 
   i.e. Google API's 
3. #empty templates manged in common functional components just pass values and reuse it.
   i. Seperate static components 
   ii. Events components 
