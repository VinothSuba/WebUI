export const GOOGLE_API: string = `https://www.googleapis.com/books/v1/volumes`;
export const KEY = '[okreads API] Reading List';