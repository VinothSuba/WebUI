export const environment = {
  production: false
};
